require("dotenv").config({ path: __dirname + "/.env" });

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { GoogleGenAI } = require("@google/genai");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({
  crossOriginResourcePolicy: false
}));

app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.use(rateLimit({
  windowMs: 60 * 1000,
  max: 30
}));

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "Kali Command AI Backend",
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY)
  });
});

app.post("/api/ai", async (req, res) => {
  try {
    const { prompt } = req.body || {};

    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({
        error: "Please provide a prompt."
      });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({
        error: "Gemini API key is not configured.",
        setup: "Add GEMINI_API_KEY to backend/.env"
      });
    }

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt
    });

    const text =
      response.text ||
      "The AI returned an empty response.";

    res.json({
      ok: true,
      answer: text
    });

  } catch (error) {
    console.error("Gemini error:", error);

    res.status(500).json({
      ok: false,
      error: error.message || "AI request failed"
    });
  }
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`Kali Command AI backend running on port ${PORT}`);
});
